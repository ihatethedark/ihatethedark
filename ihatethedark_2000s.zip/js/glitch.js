
const text = document.querySelector('p');
let i = 0;
const original = text.innerText;
text.innerText = '';
function typeWriter() {
  if (i < original.length) {
    text.innerText += original.charAt(i);
    i++;
    setTimeout(typeWriter, 35);
  }
}
window.onload = typeWriter;
